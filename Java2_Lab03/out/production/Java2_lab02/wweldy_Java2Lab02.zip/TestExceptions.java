/*****************************************
 * Class: CIST 2372 Java Programming II
 * Semester: SPRING 2020
 * Instructor: Ron Enz
 *
 * @author William  G.  Weldy
 * @version 1.0
 *****************************************/


public class TestExceptions {

    public static void main(String[] args) {
        try {
            int myArr = new int[10];
            int x, y, z;
            x = 0;
            y = 10;
            z = y / x;

            myArr[10] = 0;
        }
        catch(Exception e) {
            System.out.println("EXCEPTION THROWN!!!!");
        }
    }
}
